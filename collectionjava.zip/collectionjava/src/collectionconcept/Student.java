package collectionconcept;


public class Student {
	String name;
	String age;
	int id;
	


	public Student(String name, String id, int age) {
		super();
		this.name = name;
		this.id = age;
		this.age = id;
	}



	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + ", id=" + id + "]";
	}



}
