package collectionconcept;

import java.util.ArrayList;
import java.util.Collections;


public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		ArrayList<String> ar = new ArrayList<String>(); {
			ar.add("rago");
			ar.add("vijay");
			ar.add("arun");
			Collections.sort(ar);
//			for(int i=0;i<ar.size();i++) 
//				System.out.println("Name of the Student: "+ar.get(i)); 		 }
		ar.forEach((n)->{System.out.println("Name of the Student: " +n);});
		ArrayList<String> age= new ArrayList<String>(); {
			age.add("24");
			age.add("25");
			age.add("27");
			Collections.sort(age);
//			for(int i=0;i<age.size();i++) 
//				System.out.println("Student age " +age.get(i)); 
			age.forEach((b)->{System.out.println("Student age " +b);});
			ArrayList<Integer> id = new ArrayList<>(); {
				id.add(1);
				id.add(2);
				id.add(3);
				Collections.sort(id);
//				for(int i=0;i<id.size();i++) 
//					System.out.println("Student id is "+id.get(i)); 		 }
				id.forEach((b)->{System.out.println("Student id " +b);});
			
			
			}
	}
	}}}




//ArrayList<Student> ar = new ArrayList<String>(); 
//ar.add(new Student( "rago","24",1)); 
//ar.add(new Student( "vijay", "25",2)); 
//ar.add(new Student( "siva","27",3)); System.out.println(ar); 
//Collections.sort(ar,new SortedByRoll()); 

//{
//for(int i=0;i<ar.size();i++) 
//	 System.out.println(ar.get(i)); 
//}