package collectionconcept;

import java.util.Comparator;

public class SortedByRoll implements Comparator<Student>{

	@Override
	public int compare(Student a, Student b) {
		// TODO Auto-generated method stub
		return a.id-b.id;

}}
